<?php
		session_start(); 				// Session wird begonnen
		session_destroy();				// Session wird zerstoert
		header('Location: index.php');	// der Benutzer wird umgeleitet
?>