<?php
// Ausgabepufferung aktivieren
ob_start(); 		
	// Beginn vom Session
	session_start(); 														
	// alle Bauteile im inaktiven Zustand "0" in Sessions speichern
	$_SESSION['led1'] = "0";
	$_SESSION['led2'] = "0";
	$_SESSION['led3'] = "0";
	$_SESSION['led4'] = "0";
	$_SESSION['led5'] = "0";
	$_SESSION['posF1'] = "0";
	$_SESSION['posF2'] = "0";
	$_SESSION['posG'] = "170";
	$_SESSION['posT'] = "150";
	$_SESSION['hg'] = "0";
	$_SESSION['ka'] = "0";
	$_SESSION['vnt'] = "0";

	// wenn der Benutzer schon eingeloggt ist, kommt er zum action Seite
	if(isset($_SESSION["logged_in"]) ) {
		header('Location: action.php');

	}

?>

<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Home Smart Home</title>

        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/ico/favicon.png">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">

    </head>

    <body>

        <!-- Top content -->
        <div class="top-content">
        	
            <div class="inner-bg">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-8 col-sm-offset-2 text">
                            <h1>Home Smart Home</h1>
                            <div class="description">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-3 form-box">
                        	<div class="form-top">
                        		<div class="form-top-left">
                        			<h3>Login</h3>
                            		<p>Fill in the gaps to control your home: </p>
                        		</div>
                        		<div class="form-top-right">
                        			<i class="fa fa-key"></i>
                        		</div>
                            </div>
							 <!-- Formular besteht aus einem Benutzernamen, Passwort, IP Adresse und Port. Benutzer muss sie erfuellen um einzuloggen -->
			                <div class="form-bottom">
			                    <form role="form" action="" method="post" class="login-form">
			                    	<div class="form-group">
			                    		<label class="sr-only" for="username">Username</label>
			                        	<input type="text" name="username" placeholder="Username..." class="form-username form-control" id="username">
			                        </div>
			                        <div class="form-group">
			                        	<label class="sr-only" for="form-password">Password</label>
			                        	<input type="password" name="password" placeholder="Password..." class="form-password form-control" id="password">
			                        </div>
									<div class="form-group">
			                    		<label class="sr-only" for="ipaddress">IP Address</label>
			                        	<input type="text" name="ipaddress" placeholder="IP Address..." class="form-ipaddress form-control" id="ipaddress">
			                        </div>
									<div class="form-group">
			                    		<label class="sr-only" for="port">Port</label>
			                        	<input type="text" name="port" placeholder="Port..." class="form-port form-control" id="port">
			                        </div>
			                        <button type="submit" name ="login" class="btn">Sign in!</button>
			                    </form>
						<?php
						
						// Wenn die Werte der Benutzername und Passwort eingesetzt, also NICHT NULL sind wird $isValid wird auf true gesetzt
						if (isset($_POST['username']) && isset($_POST['password'])){ 		
							$isValid = true; 																	// Variable, die "checkt", ob die Schritte zum Einloggen erfuellt sind 
								
								if (!preg_match('/[a-zA-Z]{4,15}/', $_POST['username'])){ 						// Regex: NUR Buchstaben von a-z, klein oder gross, 4-15 Zeichen
									$isValid = false; 															// wenn die Ergaenzung nicht richtig ist, $isValid falsch
									echo "Please only use characters";											// Benutzer bekommt eine Nachricht
								}
								if (!preg_match('/[0-9]{4,10}/', $_POST['password'])){	 						// Regex: NUR Zahlen von 0-9, 4-10 Zeichen
									$isValid = false; 															// wenn die Ergaenzung nicht richtig ist, $isValid falsch
									echo "Please only use numbers"; 											// Benutzer bekommt eine Nachricht
								}
								if (!preg_match('/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/', $_POST['ipaddress'])){ // Regex: 4 Blockzahlen, jeder Blockzahl 3 Zeichen, Zahlen von 0-9.
									$isValid = false; 															// wenn die Ergaenzung nicht richtig ist, $isValid falsch
									echo "Please only use a valid IP Address";									// Benutzer bekommt eine Nachricht
								}
								if (!preg_match('/[0-9]{4,5}/', $_POST['port'])){ 								// Regex: NUR Zahlen von 0-9, 4-5 Zeichen
									$isValid = false; 															// wenn die Ergaenzung nicht richtig ist, $isValid falsch
									echo "Please only use a valid Port number"; 								// Benutzer bekommt eine Nachricht
								}
								
								
								
								// Wenn $istValid falsch ist, geht der Benutzer zum Startseite. Er kann nicht einloggen:
								if($isValid==false){ 
									header('Location: index.php');
									echo "Can't log in";
									exit();
								} 
									
							// Benutzername, Passwort, IP Adresse, Port in Sessions gespeichert und mittels POST uebermittelt die Daten:
							$_SESSION['username'] = $_POST['username'];
					//		$_SESSION['password'] = $_POST['password'];
							$_SESSION['ipaddress'] = $_POST['ipaddress'];
							$_SESSION['port'] = $_POST['port'];
					//		$hashed_password = password_hash($_POST['password'], PASSWORD_DEFAULT);				// HASH
							$hashed_password = md5(trim($_POST['password']));
							$_SESSION['password'] = $hashed_password;
					
					
							// Socket auf 3 Teile aufgeteilt: Protokoll, IP Adresse, Port
							$protocol = "tcp://";
							$address = $_POST["ipaddress"];
							$port = $_POST["port"];
							$socket = $protocol.$address.":".$port; 											// Verbindung der Variablen
							$client = stream_socket_client($socket, $errno, $errorMessage); 					// Socketverbindung begonnen
							
							if ($client === false) {
									throw new UnexpectedValueException("Failed to connect: $errorMessage"); 	// Wenn der Socket falsch ist, kommt eine Exception 
							}
		
							$_SESSION['socket'] = $client;
							// socket_set_timeout($client, 0, 500);
							fwrite($client, "login:".$_POST['username'].":".$hashed_password."\n"); 			// schreibt der Benutzername und Passowrt
							fflush($client); // schickt die String zum Server
						
							ini_set('max_execution_time', 300); 												// Wartet maximal 300 Sekunden. Wenn es Fehler gibt dann wird es unterbrochen
							$reply = trim(fgets($client)); 														// bekommt eine Antwort vom Server und trimmt die extra Zeichen
                            echo $reply;
							    
							var_dump(get_defined_vars()); 
							
							// ueberprueft ob die Antwort login_successful ist
								if($reply == "login_successful"){												
									$_SESSION["logged_in"]=true;	 											// wenn die Antwort so ist, der Benutzer ist eingeloggt
									header('Location: action.php');  											// der Benutzer kommt zum Action Seite
								    fwrite($client,"logout\n"); 												// schreibt eine logout, weil der Socket geschlossen sein soll
								    fflush($client); 															// schickt es zum Server									
									fgets($client); 															// bekommt eine Nachricht vom Server
									fclose($client); 															// schliesst den Socket
									//	fflush($client);
								} else {
									echo "False Username or Password"; 											// wenn die Antwort nicht so ist, bekommt der Benutzer eine Meldung
									header('Location: index.php'); 												// der Benutzer bleibt im Startseite
									fwrite($client,"logout\n"); 												// schreibt eine logout, weil der Socket geschlossen sein soll
								    fflush($client);															// schickt es zum Server
								    fgets($client); 															// bekommt eine Nachricht vom Server
									fclose($client); 															// schliesst den Socket
								}
								ini_set('max_execution_time', 300); 											// Wartet maximal 300 Sekunden. Wenn es Fehler gibt dann wird es unterbrochen
								//echo stream_get_contents($client);
						} 				
						?> 
				 
		                    </div>
                        </div>
                    </div>
         
                </div>
            </div>
            
        </div>


        <!-- Javascript -->
        <script src="assets/js/jquery-1.11.1.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.backstretch.min.js"></script>
        <script src="assets/js/scripts.js"></script>
        
        <!--[if lt IE 10]>
            <script src="assets/js/placeholder.js"></script>
        <![endif]-->

    </body>

</html>
<?php
ob_end_flush();
?>