<?php
session_start(); 																						// Session wird begonnen
ob_start(); 																							// Ausgabepufferung aktivieren
		
		// nochmal den Socket aufbauen
		$protocol = "tcp://";
		$address = $_SESSION["ipaddress"];
		$port = $_SESSION["port"];
	
		$socket = $protocol.$address.":".$port; 
	
		$client = stream_socket_client($socket, $errno, $errorMessage);

		if ($client === false) {
			throw new UnexpectedValueException("Failed to connect: $errorMessage");
		}
		// Benutzername und Passwort vom vorher werden nochmal geschickt
		fwrite($client, "login:".$_SESSION['username'].":".$_SESSION['password']."\n"); 
		fflush($client);	
		trim(fgets($client));
		
		if(isset($_POST['getState'])){ // wenn der Benutzer den 'getState' Button klickt
			// echo "test";
			
			// schreibt ein Get und schickt es mittels eines Sockets
			fwrite($client, "Get\n"); 
			fflush($client);	

					$getState=trim(fgets($client)); 													// bekommt eine Nachricht vom Server und trimmt die extra Zeichen
					
					if($getState == "get_accepted") { 													// wenn die Nachricht gleich mit 'get_accepted' ist
						$array = explode(":", trim(fgets($client)));									// die Antwort wird in einem Variable nammens Array gespeichert und wird die ':' weggeben
						// var_dump($array);
						// alle Werte der Bauteile werden in Sessions und Arrays gespeichert
						$_SESSION['led1'] = $array[1];
						$_SESSION['led2'] = $array[3];
						$_SESSION['led3'] = $array[5];
						$_SESSION['led4'] = $array[7];
						$_SESSION['led5'] = $array[9];
						$_SESSION['posF1'] = $array[11];
						$_SESSION['posF2'] = $array[13];
						$_SESSION['posG'] = $array[15];
						$_SESSION['posT'] = $array[17];
						$_SESSION['hg'] = $array[19];
						$_SESSION['ka'] = $array[21];
						$_SESSION['vnt'] = $array[23];


						// gibt jedem Bauteil zwei Positionen in Array. Die erste Position ist der Bauteil und die zweite ist der Wert
						$led1 = $array[0]." " .$array[1]."\n"; 
						$led2 = $array[2]." " .$array[3]."\n";
						$led3 = $array[4]." " .$array[5]."\n";
						$led4 = $array[6]." " .$array[7]."\n";
						$led5 = $array[8]." " .$array[9]."\n";
				     	$posF1 = $array[10]." ". $array[11]."\n";
						$posF2 = $array[12]." ". $array[13]."\n";
						$posG = $array[14]." ". $array[15]."\n";
						$posT = $array[16]." ". $array[17]."\n";
						$hg = $array[18]." ". $array[19]."\n";
						$ka = $array[20]." ". $array[21]."\n";
						$vnt = $array[22]." ". $array[23]."\n";
					}else{
			
					echo "ERROR"; 																		// wenn es falsch ist, dann wird eine Meldung geben 
				
					}
		}
		
	
		
					if(isset($_POST['updateState'])) { 													// wenn der Benutzer den 'updateState' Button klickt
					// schreibt ein Update und schickt es mittels eines Sockets
					fwrite($client, "Update\n"); 
					fflush($client);
			
					$updateState=trim(fgets($client)); 													// bekommt eine Nachricht vom Server und trimmt die extra Zeichen
			 
						if($updateState == "update_accepted") { 										// wenn die Nachricht gleich mit 'update_accepted' ist
							// Benutzername, Passwort, IP Adresse, Port in Sessions gespeichert und mittels POST uebermittelt die Daten
							$_SESSION['led1'] = $_POST['led1'];
							$_SESSION['led2'] = $_POST['led2'];
							$_SESSION['led3'] = $_POST['led3'];
							$_SESSION['led4'] = $_POST['led4'];
							$_SESSION['led5'] = $_POST['led5'];
							$_SESSION['posF1'] = $_POST['posF1'];
							$_SESSION['posF2'] = $_POST['posF2'];
							$_SESSION['posG'] = $_POST['posG'];
							$_SESSION['posT'] = $_POST['posT'];
							$_SESSION['hg'] = $_POST['hg'];
							$_SESSION['ka'] = $_POST['ka'];
							$_SESSION['vnt'] = $_POST['vnt'];

							// ueberprueft ob die Werte der Bauteile 1, 0, 90, 180 etc sind und je nach Wert wird eine Variable initialisiert
							if($_POST['led1'] == "1") {	
								$led1 = "led1:1";
							}else{
								$led1 = "led1:0";
							}
						
							if($_POST['led2'] == "1") {	
								$led2 = "led2:1";
							}else {
								$led2 = "led2:0";
							}
					
							if($_POST['led3'] == "1") {	
								$led3 = "led3:1";
							}else {
								$led3 = "led3:0";
							}
					
							if($_POST['led4'] == "1") {	
								$led4 = "led4:1";
							}else {
								$led4 = "led4:0";
							}
					
							if($_POST['led5'] == "1") {	
								$led5 = "led5:1";
							}else {
								$led5 = "led5:0";
							}
 					
							if($_POST['posF1'] == "25") {	
								$posF1 = "posF1:25";
							}elseif($_POST['posF1'] == "50") {
								$posF1 = "posF1:50";
							}else {
								$posF1 = "posF1:0";
							}
					
							if($_POST['posF2'] == "25") {	
								$posF2 = "posF2:90";
							}elseif($_POST['posF2'] == "50") {
								$posF2 = "posF2:50";
							}else {
								$posF2 = "posF2:0";
							}
					
							if($_POST['posG'] == "80") {	
								$posG = "posG:80";
							}else {
								$posG = "posG:170";
							}
					
							if($_POST['posT'] == "40") {	
								$posT = "posT:40";
							}else{
								$posT = "posT:150";
							}
					
							if($_POST['hg'] == "1") {	
								$hg = "hg:1";
							}else{
								$hg = "hg:0";
							}
					
							if($_POST['ka'] == "1") {	
								$ka = "ka:1";
							}else {
								$ka = "ka:0";
							}
					
							if($_POST['vnt'] == "180") {	
								$vnt = "vnt:180";
							}elseif($_POST['vnt'] == "255") {
								$vnt = "vnt:255";
							}else {
								$vnt = "vnt:0";
							}
					
							// alle Bauteilen werden mit ':' verbunden und in einem anderen Variable gespeichert
							$msg = $led1.":".$led2.":".$led3.":".$led4.":".$led5.":".$posF1.":".$posF2.":".$posG.":".$posT.":".$hg.":".$ka.":".$vnt."\n";
							// echo "message: ".$msg;
					
					
							// schickt mittels des Sockets eine Nachricht zum Server schicken
							fwrite($client, $msg);
							fflush($client);	
							ini_set('max_execution_time', 5); 											// Wartet maximal 5 Sekunden. Wenn es Fehler gibt dann wird es unterbrochen


						}else{
							echo "Fehler"; 																// Es wird ein Meldung geben, wenn es Fehler gibt
						}
		}
		
		
		// schreibt eine Logout, bekommt eine Nachricht vom Server und schliesst den Socket
		fwrite($client,"logout\n");
		fflush($client);
		fgets($client);			 
		fclose($client);
		

		// wenn der Benutzer eingeloggt ist bleibt er im ActionSeite, im Gegenteil wenn er nicht eingeloggt ist
		if (! empty($_SESSION['logged_in'])){

		}
		else{
			header('Location: index.php');;
		}
																							// Ausgabepufferung schliessen
?>
<!DOCTYPE html>
<html lang="en">

    <head>
		<style>
		.btn1{
			width:10%;
			display:inline-block;
		}
		.btn2{
			width:10%;
			display:inline-block;
		}
		.lg {
			text-align: right;
		}
		.form-top{
			height:100px;
		}
		
		</style>

	
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Your Home</title>

        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">


        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/ico/favicon.png">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">

    </head>

    <body>

        <!-- Top content -->
        <div class="top-content">
        	
            <div class="inner-bg">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-8 col-sm-offset-2 text" >
                            <h1><strong></strong>Home Smart Home</h1>
                            <div class="description">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        	<div class="form-top"><span>
                        		<div class="form-top-left">
                        			<h3> Control your home: </h3>
								</div>
                        		<div class="form-top-right">
                        			<i class="fa fa-home" ></i>
									
                        		</div>
								
                            </div>

							<!-- Formular, die aus allen Bauteilen besteht -->
							<!-- Jeder Radiobutton hat seinen eigenen Value. Wenn sie geklickt sind, bekommen sie seinen Wert und speichern sie es -->

							<div class="form-bottom">
			                    <form action="action.php" method="post">
									<div class="l1 col-md-3">
			                    	<div class="form-group">
										<img src="light.png">
										<label for="lights">Lights</label></br>
			                    		<label class="radio-inline"> <input type="radio" name="led1" value="0"   <?php if($_SESSION['led1'] == "0" ){ echo "checked='checked'"; }?> <span class="label-text"> Light 1 off </span> </label>
										<label class="radio-inline"> <input type="radio" name="led1" value="1"   <?php if($_SESSION['led1'] == "1" ){ echo "checked='checked'"; }?> <span class="label-text"> Light 1 on </span> </label>
									</div>
			                        <div class="form-group">
			                    		<label class="radio-inline"> <input type="radio" name="led2" value="0"   <?php if($_SESSION['led2'] == "0" ){ echo "checked='checked'"; }?> <span class="label-text"> Light 2 off </span> </label>
										<label class="radio-inline"> <input type="radio" name="led2" value="1"   <?php if($_SESSION['led2'] == "1" ){ echo "checked='checked'"; }?> <span class="label-text"> Light 2 on </span> </label>
									</div>
									<div class="form-group">
			                    		<label class="radio-inline"> <input type="radio" name="led3" value="0"   <?php if($_SESSION['led3'] == "0" ){ echo "checked='checked'"; }?> <span class="label-text"> Light 3 off </span> </label>
										<label class="radio-inline"> <input type="radio" name="led3" value="1"   <?php if($_SESSION['led3'] == "1" ){ echo "checked='checked'"; }?> <span class="label-text"> Light 3 on </span> </label>
									</div>
									<div class="form-group">
			                    		<label class="radio-inline"> <input type="radio" name="led4" value="0"   <?php if($_SESSION['led4'] == "0" ){ echo "checked='checked'"; }?> <span class="label-text"> Light 4 off </span> </label>
										<label class="radio-inline"> <input type="radio" name="led4" value="1"   <?php if($_SESSION['led4'] == "1" ){ echo "checked='checked'"; }?> <span class="label-text"> Light 4 on </span> </label>
									</div> 
									<div class="form-group">
			                    		<label class="radio-inline"> <input type="radio" name="led5" value="0"   <?php if($_SESSION['led5'] == "0" ){ echo "checked='checked'"; }?> <span class="label-text"> Light 5 off </span> </label>
										<label class="radio-inline"> <input type="radio" name="led5" value="1"   <?php if($_SESSION['led5'] == "1" ){ echo "checked='checked'"; }?> <span class="label-text"> Light 5 on </span> </label>
									</div>
									</div>
									
									<div class="l2 col-md-3">									
									<div class="form-group">
										<img src="blind.png">
										<label for="1windowroll">1 window roll</label></br>
			                    		<label class="radio-inline"> <input type="radio" name="posF1" value="0"   <?php if($_SESSION['posF1'] == "0" ){ echo "checked='checked'"; }?> <span class="label-text"> Close 1 window roll </span> </label> </br>
										<label class="radio-inline"> <input type="radio" name="posF1" value="25"   <?php if($_SESSION['posF1'] == "25" ){ echo "checked='checked'"; }?> <span class="label-text"> Open 1 window roll in half </span> </label> </br>
										<label class="radio-inline"> <input type="radio" name="posF1" value="50"   <?php if($_SESSION['posF1'] == "50" ){ echo "checked='checked'"; }?> <span class="label-text"> Open 1 window roll </span> </label> </br>
									</div>																		
									<div class="form-group">
										<img src="blind.png">
										<label for="2windowroll">2 window roll</label></br>
			                    		<label class="radio-inline"> <input type="radio" name="posF2" value="0"   <?php if($_SESSION['posF2'] == "0" ){ echo "checked='checked'"; }?> <span class="label-text"> Close 2 window roll </span> </label> </br>
										<label class="radio-inline"> <input type="radio" name="posF2" value="25"   <?php if($_SESSION['posF2'] == "25" ){ echo "checked='checked'"; }?> <span class="label-text"> Open 2 window roll in half </span> </label> </br>
										<label class="radio-inline"> <input type="radio" name="posF2" value="50"   <?php if($_SESSION['posF2'] == "50" ){ echo "checked='checked'"; }?> <span class="label-text"> Open 2 window roll </span> </label> </br>
									</div>
									</div>
									<div class="l3 col-md-3">
									<div class="form-group">
										<img src="grg.png">
										<label for="garagedoor">Garage Door</label></br>
			                    		<label class="radio-inline"> <input type="radio" name="posG" value="170"   <?php if($_SESSION['posG'] == "170" ){ echo "checked='checked'"; }?> <span class="label-text"> Close garage door </span> </label> </br>
										<label class="radio-inline"> <input type="radio" name="posG" value="80"   <?php if($_SESSION['posG'] == "80" ){ echo "checked='checked'"; }?> <span class="label-text"> Open garage door </span> </label> </br>
									</div>
									<div class="form-group">
										<img src="door.png">
										<label for="door">Door</label></br>
			                    		<label class="radio-inline"> <input type="radio" name="posT" value="150"   <?php if($_SESSION['posT'] == "150" ){ echo "checked='checked'"; }?> <span class="label-text"> Close door </span> </label> </br>
										<label class="radio-inline"> <input type="radio" name="posT" value="40"   <?php if($_SESSION['posT'] == "40" ){ echo "checked='checked'"; }?> <span class="label-text"> Open door </span> </label> </br>
									</div>
									<div class="form-group">
										<img src="heat.png">
										<label for="heater">Heater</label></br>
			                    		<label class="radio-inline"> <input type="radio" name="hg" value="0"   <?php if($_SESSION['hg'] == "0" ){ echo "checked='checked'"; }?> <span class="label-text"> Heater off </span> </label> </br>
										<label class="radio-inline"> <input type="radio" name="hg" value="1"   <?php if($_SESSION['hg'] == "1" ){ echo "checked='checked'"; }?> <span class="label-text"> Heater on </span> </label> </br>
									</div>
									</div>
									<div class="l4 col-md-3">
									<div class="form-group">
										<img src="ac.png">
										<label for="ac">Air Condition</label></br>
			                    		<label class="radio-inline"> <input type="radio" name="ka" value="0"   <?php if($_SESSION['ka'] == "0" ){ echo "checked='checked'"; }?> <span class="label-text"> AC off </span> </label> </br>
										<label class="radio-inline"> <input type="radio" name="ka" value="1"   <?php if($_SESSION['ka'] == "1" ){ echo "checked='checked'"; }?> <span class="label-text"> AC on </span> </label> </br>
									</div>
										<div class="form-group">
										<img src="vnt.png">
										<label for="ventilator">Ventilator</label></br>
			                    		<label class="radio-inline"> <input type="radio" name="vnt" value="0"   <?php if($_SESSION['vnt'] == "0" ){ echo "checked='checked'"; }?> <span class="label-text"> Ventilator off </span> </label> </br>
										<label class="radio-inline"> <input type="radio" name="vnt" value="180"   <?php if($_SESSION['vnt'] == "180" ){ echo "checked='checked'"; }?> <span class="label-text"> Ventilator half on </span> </label> </br>
										<label class="radio-inline"> <input type="radio" name="vnt" value="255"   <?php if($_SESSION['vnt'] == "255" ){ echo "checked='checked'"; }?> <span class="label-text"> Ventilator on </span> </label> </br>
										</div>
									</div>
								
								<div class="btn1">
								<button type="submit" name="getState" class="btn" id ="getState"  value="getState">Refresh</button>	
								</div>
								<div class="btn2">
								<button type="submit" name="updateState" class="btn" id ="updateState"  value="updateState">Update</button>		
								</div>
								</form>
									
		                    
							<!-- Output zeigt das Ergebnis -->
							<output name="x" for="a b"></output>
							<!-- Textarea, wo die Get Methode gezeigt wird. Der Benutzer hat nur lese Rechte -->
							<!-- Alle Bauteile mit seinen eigenen Wert werden angezeigt, wenn die Button geklickt ist -->
							<textarea rows="15" cols="130" readonly><?php if(isset($_POST['getState'])) { echo $led1; echo $led2  ; echo $led3; echo $led4; echo $led5; echo $posF1; echo $posF2; echo $posG; echo $posT; echo $hg; echo $ka; echo $vnt; } else { }?>
							
							</textarea>
							
							<div class="lg">
							<a href="logout.php" class="btn btn-secondary btn-lg active" role="button" aria-pressed="true">Logout</a>
							</div>
                        </div>
                    </div>
				</div>
				</div>
                </div>
            </div>
            
        


        <!-- Javascript -->
        <script src="assets/js/jquery-1.11.1.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.backstretch.min.js"></script>
        <script src="assets/js/scripts.js"></script>
        
        <!--[if lt IE 10]>
            <script src="assets/js/placeholder.js"></script>
        <![endif]-->

    </body>

</html>

<?php
//ob_flush();	
ob_end_flush();